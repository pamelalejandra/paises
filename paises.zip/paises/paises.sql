-- 1.
SELECT * FROM countrylanguage;
SELECT CountryCode, Language, percentage FROM countrylanguage
WHERE Language = "Slovene";

-- 2.
SELECT co.name, cl.language, COUNT(c.id) as ciudad
FROM city c
INNER JOIN country co ON co.CODE = c.CountryCode
INNER JOIN countrylanguage cl ON cl.CountryCode = co.CODE
GROUP BY co.CODE, cl.language
ORDER BY ciudad DESC;

-- 3.
SELECT p.name, c.name, c.Population
FROM country p INNER JOIN city c ON p.Code = c.CountryCode
WHERE c.CountryCode ="MEX"
AND c.Population > 500000
ORDER BY c.Population DESC;

-- 4.
SELECT p.name, l.language, l.Percentage
FROM country p INNER JOIN countrylanguage l ON p.code = CountryCode
WHERE l.Percentage >89
ORDER BY l.Percentage DESC;

-- 5.
SELECT p.name, p.SurfaceArea, p.Population FROM country p
WHERE p.SurfaceArea <501 AND p.Population >100000;

-- 6.
SELECT p.name, p.GovernmentForm, p.capital, p.LifeExpectancy FROM country p
WHERE p.GovernmentForm = 'Constitutional Monarchy'
AND p.capital >200
AND p.LifeExpectancy >75;

-- 7.
SELECT p.Name, c.Name, c.District, c.Population
FROM country p INNER JOIN city c ON c.CountryCode = p.Code
WHERE p.Code = 'ARG'
AND District = 'Buenos Aires'
AND c.Population > 500000;

-- 8.
SELECT Region, COUNT(Code) as countries from country
GROUP BY Region
ORDER BY countries DESC;